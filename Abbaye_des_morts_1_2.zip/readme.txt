-----------------------------------------

L'ABBAYE DES MORTS 1.2 �2010

A game by Locomalito
Music and cover art by Gryzor87

-----------------------------------------

PLAYING WITH KEYBOARD:
Arrows - Walk, crouch, teleport
Space - Jump
I - Instructions (main title)
Enter - Start, Pause
F1 - Noisy image filter
Esc - Quit game

PLAYING WITH GAMPEAD:
Pad - Walk, crouch, teleport
Button 1 - Jump
Button 2 - Instructions (main title)
Start - Start, Pause
Select - Noisy image filter

-----------------------------------------

Version 1.2 notes

Some sprites and room designs has been
polished to look and work better.
XInput gamepads are supported natively.

-----------------------------------------

L'ABBAYE DES MORTS IS A FREEWARE GAME

You don't have to pay for playing,
but if you feel it worth it, you can 
support the project making a donation,
writing about the game, spreading the 
file or making your own freeware games.

www.locomalito.com

-----------------------------------------

Thanks to Pixel for creating PXTone,
used to write the music.
Thanks to Shiru for creating BeepFX,
used for the sound effects.

-----------------------------------------

Have fun :-)

-----------------------------------------